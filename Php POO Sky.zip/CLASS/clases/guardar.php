<?php
//archivo que contiene las deficiones 
require_once("clases.php");
//meotodo POST 
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$tipo = $_POST['tipo'];
$ciudad = $_POST['ciudad'];
//new instancia 
$trabajo = new Trabajo();
//llamar al guardarCliente de clases.php
$resultado = $trabajo->guardarCliente($id, $nombre, $apellido, $direccion, $telefono, $tipo, $ciudad);
//validacion
if ($resultado) {
    echo "<script>alert('Cliente registrado.'); window.location.href = 'index.php';</script>";
} else {
    echo "<script>alert('Cliente NO registrado.'); window.location.href = 'index.php';</script>";
}
?>
