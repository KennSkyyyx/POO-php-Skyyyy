<?php 
	//conexionbase de datos
	require_once("conexion.php");

	// Definir clase Trabajo, 
	// se extiende a la clase de conexión.
	class Trabajo extends Conexion 
	{ 
	// private para acceder datos.
	private $datos;

	// Constructor clase
	public function __construct()
	{
	// Llamada constructor Conexion.php establecer cx
	parent::__construct();
	}

	// metodo traer_datos
	public function Traer_datos($inicio)
	{
	$uno=4;
	$dos=4;
		// $sql para seleccionar toda la informacion de la tabla clientes
		//y ejecutar la consulta $consul
		//$res =resultado de la consulta
		$sql="select * from clientes";
		$consul=$this->conex->query($sql);
		$res=$consul->fetch_all(MYSQLI_ASSOC);
		return $res;
	}

	// metodo cambiar_datos
	public function cambiar_datos($v6)
	{
		// $SQL1 descripción del tipo por su id
		$sql1="select Descripcion_tipo from tipo_cli Where Id_tipo=$v6";
		$consul=$this->conex->query($sql1);
		$res=$consul->fetch_all(MYSQLI_ASSOC);
		return $res;
	}

	// metodo cambiar_datos ciudad
	public function cambiar_datos2($v7)
	{
		// $sql para obtener el nick de la ciudad por la id
		$sql="select Nombre_Ciudad from ciudad Where Id_ciudad=$v7";
		$consul2=$this->conex->query($sql);
		$res2=$consul2->fetch_all(MYSQLI_ASSOC);
		return $res2;
	}
		
	// metodo seleccionar camp 
	public function seleccion_camp($var)
	{
		// esto es para imprrmir los datos atraves del GET
		print_r($_GET);
		die();
	}

	// metodo traer_ciudad
	// seleccionar tabla ciudad
	// resultados y consulta
	public function trae_ciudad()
	{
		$sql="select * from ciudad";
		$consul=$this->conex->query($sql);
		$res=$consul->fetch_all(MYSQLI_ASSOC);
		return $res;
	}

	// metodo tipos
	public function trae_tipo()
	{
		//sql para tipos de clientes
		//resultado y consultas
		$sql="select * from tipo_cli";
		$consul=$this->conex->query($sql);
		$res=$consul->fetch_all(MYSQLI_ASSOC);
		return $res;
	}

	// meotod cliente por id.
	public function trae_uncliente($id)
	{
    	// sql para consuktar el id
    	$sql = "SELECT * FROM clientes WHERE Id_cliente='$id'";
    	$consul = $this->conex->query($sql);
    	$res = $consul->fetch_all(MYSQLI_ASSOC);
    	return $res;
	}

	// metodo actualizar
	public function actualizaDat($va1, $va2, $va3, $va4, $va5, $va6, $va7, $cod)
	{
		//sql para cinsutar cliente por id
		//se crea los nombre de las columnas que estan en a base de datos con $
		$sql="update clientes set
		Id_cliente='$va1',
		Nombre_cli='$va2',
		Apellido_cli='$va3',
		Direccion_cli='$va4',
		Telefono_cli='$va5',
		Tipo_cli='$va6',
		Ciudad_cli='$va7'
		where Id_cliente='$cod'";
		$rs=$this->conex->query($sql);
        return $rs;
	}

	// metodo eliminar 
	public function Eliminar_cliente($id_cliente) {
		// sql para seleccionar la tabla y consultar, preparacion, resultado, parametro
		$sql = "DELETE FROM clientes WHERE id_cliente = ?";
		$stmt = $this->conex->prepare($sql);
		$stmt->bind_param("i", $id_cliente);
		$stmt->execute();
		$stmt->close();
	}

	// metodo guardar definir variables $ de la tabla
	public function guardarCliente($id, $nombre, $apellido, $direccion, $telefono, $tipo, $ciudad)
	{
		// SQL para insertar el nuevo cli
		$sql = "INSERT INTO clientes (Id_cliente, Nombre_cli, Apellido_cli, Direccion_cli, Telefono_cli, Tipo_cli, Ciudad_cli) 
				VALUES ('$id', '$nombre', '$apellido', '$direccion', '$telefono', '$tipo', '$ciudad')";
		$rs = $this->conex->query($sql);
		return $rs;
		}
	}
?>
