<?php
	// configuración para los datos de conexión. y definicion de la clase
	require_once("config.php");
	class Conexion
	{
	// Atributo para almacenar la conexión.
	protected $conex;
	// Constructo para la classee
	public function __construct()
	{
	//instancia establecer la conexión. $this
	$this->conex = new mysqli(host, user, pass, base);
		if($this->conex->connect_errno)
		{
		// return para los errores
		return;
		}
		// conjunto de caracteres cx
		$this->conex->set_charset(charst);
		}
}
?>
