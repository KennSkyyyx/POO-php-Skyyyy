<?php 
//definir la conexion a base datos "class"
	define("host","localhost");
	//usuario
	define("user","root");
	define("pass","");
	//nick de la base de datos
	define("base","class");
	define("charst","utf8");

 ?>