<?php
//meotod POST para recibir los datos enviados por el
     $idCliente = $_POST['id_cliente'];
     $nombre = $_POST['nombre'];
     $apellido = $_POST['apellido'];
     $direccion = $_POST['direccion'];
     $telefono = $_POST['telefono'];
     //conexion a base
     include 'conexion.php';
    //consulta para actualizar dates
    $query = "UPDATE clientes SET Nombre_cli='$nombre', Apellido_cli='$apellido', Direccion_cli='$direccion', Telefono_cli='$telefono' WHERE Id_cliente='$idCliente'";
    //ejecucion de la consulta
    if (mysqli_query($conexion, $query)) {
        header("Location: index.php?mensaje=Cliente actualizado correctamente");
        exit();
    } else {
        echo "Error al actualizar el cliente: " . mysqli_error($conexion);
    }
mysqli_close($conexion);
?>