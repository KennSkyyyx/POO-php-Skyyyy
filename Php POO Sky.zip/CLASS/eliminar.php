<?php
//definir la clase eliminar clientes
class EliminadorCliente {
    //almacena instancia clase
    private $trabajo;
    public function __construct() {
        require_once("clases/clases.php");
        //instancia de clase y asignada por $trabajo
        $this->trabajo = new Trabajo();
    }
    //funcion para eliminar desde su ID
    public function eliminarCliente($id_cliente) {
        //llamar a la funcion eliminarCliente
        $this->trabajo->Eliminar_cliente($id_cliente);
    }
    //funcion para redireccionar a otra pag
    public function redireccionar($url) {
        header("Location: $url");
        exit();
    }
}
//new instancia y se crea para permitir el acceso a los metodos
$eliminador = new EliminadorCliente();
if(isset($_GET['id_cliente'])) {
    $id_cliente = $_GET['id_cliente'];
    $eliminador->eliminarCliente($id_cliente);
    $eliminador->redireccionar("index.php");
}
?>