-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-05-2024 a las 03:19:06
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `class`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudad`
--

CREATE TABLE `ciudad` (
  `Id_ciudad` int(11) NOT NULL,
  `Nombre_Ciudad` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ciudad`
--

INSERT INTO `ciudad` (`Id_ciudad`, `Nombre_Ciudad`) VALUES
(11, 'Armenia'),
(3, 'Barranquilla'),
(1, 'Bogotá'),
(7, 'Bucaramanga'),
(6, 'Cali'),
(5, 'Cartagena'),
(9, 'Cúcuta'),
(10, 'Ibagué'),
(8, 'Manizales'),
(2, 'Medellin'),
(4, 'Santa Marta'),
(12, 'Tunja');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `Id_cliente` int(14) NOT NULL,
  `Nombre_cli` varchar(50) NOT NULL,
  `Apellido_cli` varchar(50) NOT NULL,
  `Direccion_cli` varchar(80) NOT NULL,
  `Telefono_cli` varchar(23) NOT NULL,
  `Tipo_cli` int(8) NOT NULL,
  `Ciudad_cli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`Id_cliente`, `Nombre_cli`, `Apellido_cli`, `Direccion_cli`, `Telefono_cli`, `Tipo_cli`, `Ciudad_cli`) VALUES
(345351416, 'Ana', 'Gómez', 'Carrera 35', '3208765432', 2, 10),
(634525211, 'Marcela', 'Gutiérrez', 'Calle 15', '3194321098', 4, 4),
(643524141, 'David', 'Ramírez', 'Avenida 20', '3223210987', 1, 2),
(745735524, 'Pedro', 'Díaz', 'Calle 5', '3177654321', 2, 7),
(931423748, 'Sofía', 'Rodríguez', 'Avenida 10', '3186543210', 1, 11),
(987654321, 'Laura', 'Martínez', 'Calle 10', '3106547890', 3, 5),
(1080650749, 'Kenner', 'Ferrer', 'CR 8B #157-10', '3224197138', 1, 11),
(1111111112, 'Lucía', 'Sánchez', 'Carrera 45', '3232109876', 1, 11),
(1234567899, 'Skynet', 'Sequera', 'Carrera 301', '3009874563', 1, 11),
(1235452411, 'Juan', 'Pérez', 'Avenida 15', '3019876543', 1, 11),
(1564839671, 'Jean', 'Contreras', 'Calle 20', '3145681891', 2, 1),
(1567241313, 'Jorge', 'Hernández', 'Carrera 40', '3215432109', 4, 9),
(1823478237, 'Diego', 'Chaparro', 'Calle 178', '3128147881', 1, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_cli`
--

CREATE TABLE `tipo_cli` (
  `Id_tipo` int(8) NOT NULL,
  `Descripcion_tipo` varchar(50) NOT NULL,
  `Comentario` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_cli`
--

INSERT INTO `tipo_cli` (`Id_tipo`, `Descripcion_tipo`, `Comentario`) VALUES
(1, 'Clase Alta', 'Pertenece a la clase A '),
(2, 'Clase Media', 'Pertenece a la clase M'),
(3, 'Clase Baja', 'Pertenece a la clase B'),
(4, 'Clase Muy Baja', 'Pertenece a la clase M-B');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ciudad`
--
ALTER TABLE `ciudad`
  ADD PRIMARY KEY (`Id_ciudad`),
  ADD UNIQUE KEY `Id_ciudad` (`Id_ciudad`),
  ADD KEY `Nombre_Ciudad` (`Nombre_Ciudad`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`Id_cliente`),
  ADD UNIQUE KEY `Id_cliente` (`Id_cliente`),
  ADD KEY `Ciudad_cli` (`Ciudad_cli`),
  ADD KEY `Tipo_cli` (`Tipo_cli`);

--
-- Indices de la tabla `tipo_cli`
--
ALTER TABLE `tipo_cli`
  ADD PRIMARY KEY (`Id_tipo`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_2` FOREIGN KEY (`Tipo_cli`) REFERENCES `tipo_cli` (`Id_tipo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `clientes_ibfk_3` FOREIGN KEY (`Ciudad_cli`) REFERENCES `ciudad` (`Id_ciudad`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
