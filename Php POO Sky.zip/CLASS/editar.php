<?php
	// archivo clases.php definiciones
	require_once("clases/clases.php");
	// instancia de la clase Trabajo.
	$dat=new Trabajo();
	if(!isset($_GET["id"])){	
	}
	{
	// Se asigna el valor del parámetro "id" a la variable $cod.
	$cod=$_GET["id"];
	$campos=new Trabajo();
	//se trae un nuevo cliente atraves del metodo
	$val=$campos->trae_uncliente($cod);		
	}
	//valores para cada cli
	$v6=$val[0]['Ciudad_cli'];
	$v7=$val[0]['Tipo_cli'];
	// llamar a los métodos 
	$datos_cambiados = $dat->cambiar_datos($v6);
	$datos_cambiados2 = $dat->cambiar_datos2($v7);

	// descripcionesdatos cambiados
	$v8 = isset($datos_cambiados[0]['Descripcion_tipo']) ? $datos_cambiados[0]['Descripcion_tipo'] : "No disponible";
	$v9 = isset($datos_cambiados2[0]['Nombre_Ciudad']) ? $datos_cambiados2[0]['Nombre_Ciudad'] : "No disponible";
	$ciud=$campos->trae_ciudad();
	$tipo=$campos->trae_tipo();

	// enviar el formulario POST
	if(isset($_POST["conf_val"])=="si")
	{
	// Se obtienen los valores enviados por el formulario.
	$va1=$_POST["Identificado"];
		$va2=$_POST["Nombre"];
			$va3=$_POST["Apellido"];
				$va4=$_POST["Direccion"];
					$va5=$_POST["Telefono"];
						$va6=$_POST["Tipo"];
							$va7=$_POST["Ciudad"];
								$z=0;
	//actualizar
	$resp=$dat->actualizaDat($va1 ,$va2, $va3, $va4, $va5, $va6, $va7,$cod);	
	// Se incrementa la variable $z.
	$z++;	
	if($z>0){
		echo'
		<script>
		window.location = "index.php";
		</script>
		';
		}
	}
?>
<!-- FORMULARIO GG -->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Editar Clientes</title>
	<link rel="stylesheet" href="css/style.css?v=1.0">
	<style>
			body{
				background-image: url(imgs/black_1.png);
    			background-size: cover;
    			background-position: center;
    			background-attachment: fixed;
			}
	</style>
</head>
<body>
    <!--formulario-->
    <div class="login-box">
        <label>Datos del usuario</label>
        <!--  enviar los datos a través del método POST -->
        <form id="form" method="post" action="">
            <div class="user-box">
                <!-- valor del campo se establece con el ID del cliente obtenido de la variable $val -->
				<!-- e igual con los demas -->
                <input type="text" name="Identificado" required="" value="<?php echo $val[0]['Id_cliente']?>">
				<label for="nombre">Identificacion:</label>
  
            </div>
            <div class="user-box">
                <input type="text" name="Nombre" required="" value="<?php echo $val[0]['Nombre_cli']?>"> 
				<label for="nombre">Nombre:</label>

            </div>
            <div class="user-box">
                <input type="text" name="Apellido" required="" value="<?php echo $val[0]['Apellido_cli']?>">
				<label for="nombre">Apellido:</label>

            </div>
            <div class="user-box">
                <input type="text" name="Direccion" required="" value="<?php echo $val[0]['Direccion_cli']?>">
				<label for="nombre">Direccion:</label>

            </div>
            <div class="user-box">
                <input type="text" name="Telefono" required="" value="<?php echo $val[0]['Telefono_cli']?>">
				<label for="nombre">Telefono:</label>

            </div>
            <select class="" name="Tipo" id="tip">
			

<?php 
    for($i=0;$i<sizeof($tipo);$i++){
?>
    <!-- mostrar cada elemento del arreglo $tipo -->
    <option value="<?php echo $tipo[$i]["Id_tipo"];?>"><?php echo $tipo[$i]["Descripcion_tipo"];?></option>
	
<?php		
}
?>				
    </select>
        <select class="" name="Ciudad" id="ciu">
            <?php 
                for($i=0;$i<sizeof($ciud);$i++){
                    ?>
                    <option value="<?php echo $ciud[$i]["Id_ciudad"];?>"><?php echo $ciud[$i]["Nombre_Ciudad"];?></option>
                    <?php					
                }
            ?>				
    </select>
        <button id="submitButton">Enviar</button>
            <input type="hidden" name="conf_val" value="si">
            <script>
                document.getElementById('submitButton').addEventListener('click', function() {
                    document.getElementById('form').submit();
                });
            </script>
        </form>
    </div>
</body>
</html>

