<?php
//archivos clases.php que contiene los metodos
    require_once("clases/clases.php");
    //instancia de la clase trabajo
    $campos=new Trabajo();
    $ciud=$campos->trae_ciudad();
    $tipo=$campos->trae_tipo();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Cliente</title>
    <link rel="stylesheet" href="css/estilo.css?v=1.0">
    <style>
        body{   
            background-image: url(imgs/black_1.png);
    		background-size: cover;
    		background-position: center;
    		background-attachment: fixed;
    
}  
    </style>

</head>
<body>
<!-- formulario y metodo post para enviar los datos guardar.php -->
    <form action="guardar.php" method="POST">
        <label for="id">ID Cliente:</label>
        <input type="text" id="id" name="id" required><br><br>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br><br>
        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required><br><br>
        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" required><br><br>
        <label for="telefono">Teléfono:</label>
        <input type="text" id="telefono" name="telefono" required><br><br>
        <label for="tipo">Tipo de Cliente:</label>
        <!-- metodo de id_tip y descripcion_tipo -->
        <!-- metodo de id_ciudad y nombre -->
        <select name="tipo" required="">
            <option value="">Selecciona el tipo</option>
            <?php foreach ($tipo as $t): ?>
                <option value="<?php echo $t['Id_tipo']; ?>"><?php echo $t['Descripcion_tipo']; ?></option>
            <?php endforeach; ?>
        </select><br><br>
        <label for="ciudad">Ciudad:</label>
        <select name="ciudad" required="">
            <option value="">Selecciona la ciudad</option>
            <?php foreach ($ciud as $c): ?>
                <option value="<?php echo $c['Id_ciudad']; ?>"><?php echo $c['Nombre_Ciudad']; ?></option>
            <?php endforeach; ?>
        </select><br><br>
<!-- enviar -->
        <button type="submit">Enviar</button>
    </form>
</body>
</html>
