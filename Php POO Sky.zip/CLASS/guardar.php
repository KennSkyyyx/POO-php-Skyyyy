<?php
//archivo clases.php definiciones de la clase
require_once("clases/clases.php");
//datos recibidos por el metodo POST
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$tipo = $_POST['tipo'];
$ciudad = $_POST['ciudad'];
//instancia clase trabajo
//se crea la instancia para reutilizar el codigo (encapsular la logica relacionada con los datos)
$trabajo = new Trabajo();
//aca es llamda la funcion guardarClientes de clases.php
$resultado = $trabajo->guardarCliente($id, $nombre, $apellido, $direccion, $telefono, $tipo, $ciudad);
//es para validar los datos si fue correcto o NO
if ($resultado) {
    echo "<script>alert('Cliente registrado.'); window.location.href = 'index.php';</script>";
} else {
    echo "<script>alert('Cliente NO registrado.'); window.location.href = 'index.php';</script>";
}
?>
