<?php 
    // clases.php archivos para las definiciones (clases)
    require_once("clases/clases.php");
    // instancias
    $dat = new Trabajo();
	$dat2 = new Trabajo();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Datos Registrados</title>
<style>
        body{   
            background-image: url(imgs/1.jpg);
    		background-size: cover;
    		background-position: center;
    		background-attachment: fixed;
    
}  
    </style>
</head>
<body>
    <!-- Tabla para mostrar -->
    <table width="100%" align="left" border="10">
    <thead>
        <!-- Encabezados-->
        <tr bgcolor=#FFF>
            <!-- Encabezado pri -->
            <th colspan="8">
            <h1>EMPRESA DE SOFTWARE COLOMBIA </h1>
            
            <!--  para agregar cliente -->
            <a href="new.php" style="text-decoration: none;">
            <img src="imgs/guardar.png" alt="imagen de guardar"width="40" height="40" style="cursor: pointer;">
           
            </a>
            <H2>Listado de clientes registrados</H2>
            </th>
        </tr>
        
        <!--columnas con la informacion que qse quiere mostrar-->
        <tr>
            <th style="color: black; background-color: #FFDC00;">ID</th>
            <th style="color: black; background-color: #FFDC00;">Nombres</th>
            <th style="color: black; background-color: #FFDC00;">Apellidos</th>
            <th style="color: black; background-color: #FFDC00;">Direccion</th>
            <th style="color: black; background-color: #FFDC00;"># Telefono</th>
            <th style="color: black; background-color: #FFDC00;">Ciudad</th>
            <th style="color: black; background-color: #FFDC00;">Tipo Cliente</th>
            <th style="color: black; background-color: #FFDC00;">Opciones
            
                    
</th>
                    
        </tr>           
</thead>
<tbody>
<?php
    // se envia parametro atraves del get y guardamos $inicio
    if(isset($_GET["pos"]))
    {
        $inicio=$_GET["pos"];
    }
    else
    {
        $inicio=0;
    }
    // Contador
    $cont=0;
    // lista para los clientes obtenidos
        $lista = $dat->Traer_datos($inicio);
            foreach ($lista as $cliente) {
    //para cada cliente
    $v1 = $cliente['Id_cliente'];
        $v2 = substr($cliente['Nombre_cli'], 0, 20);
            $v3 = $cliente['Apellido_cli'];
                $v4 = substr($cliente['Direccion_cli'], 0, 20);
                    $v5 = $cliente['Telefono_cli'];
                        $v6 = substr($cliente['Tipo_cli'], 0, 12);
                            $v7 = substr($cliente['Ciudad_cli'],0,12);

    // descripciones cambiadass
    $datos_cambiados = $dat->cambiar_datos($v6);
	$datos_cambiados2 = $dat->cambiar_datos2($v7);
    $v8 = isset($datos_cambiados[0]['Descripcion_tipo']) ? $datos_cambiados[0]['Descripcion_tipo'] : "No disponible";
	$v9 = isset($datos_cambiados2[0]['Nombre_Ciudad']) ? $datos_cambiados2[0]['Nombre_Ciudad'] : "No disponible";
    $cont++;
    ?>

        <tr>
            <th align="left" style="color: white; background-color: black;"><?php echo $v1;?></th>
            <th align="left" style="color: white; background-color: black;"><?php echo $v2;?></th>
            <th style="color: white; background-color: black;"><?php echo $v3;?></th>
            <th style="color: white; background-color: black;"><?php echo $v4;?></th>
            <th style="color: white; background-color: black;"><?php echo $v5;?></th>
            <th style="color: white; background-color: black;"><?php echo $v9;?></th>
            <th style="color: white; background-color: black;"><?php echo $v8;?></th>
            <th>
                <!-- imgs para editar y eliminar (clientes) -->
                <a href="editar.php?id=<?php echo $v1;?>">
                    <img src="imgs/edit.png" alt="Editar datos" width="35" height="35">  
                </a>
                <a href="eliminar.php?id_cliente=<?php echo $v1;?>" style="text-decoration: none;">
                    <img src="imgs/delete.png" alt="imagen de eliminar" width="35" height="35" style="cursor: pointer;">
                </a>

                
            </th>
            </tr>
            <!-- para cerrar un bloque del codigo php -->
            <?php
                }
            ?>     
        </tbody>
    </table>
</body>
</html>
